from deepBeliefNetworkMaster.dbn import SupervisedDBNRegression
import numpy as np
from sklearn import metrics
from sklearn.model_selection import KFold

def get_score(model, X_train, X_test, y_train, y_test):
    """Check the accuracy score for a given model, training, and testing data."""
    model.fit(X_train, y_train)
    return model.score(X_test, y_test) 

kf = KFold(n_splits=10, shuffle=True, random_state=42)

# Load train data
train_x = np.genfromtxt('train.csv', delimiter=',')
train_x = train_x.astype(np.int64).T  # Ensure correct type

# Load labels
train_y = np.loadtxt("labels_0.dat", dtype=np.int64)  # Ensure integer labels
train_a = np.loadtxt("labels_1.dat", dtype=np.int64)

# Define model for valence
clf = SupervisedDBNRegression(
    hidden_layers_structure=[100], learning_rate_rbm=0.05, learning_rate=0.05,
    n_epochs_rbm=10, n_iter_backprop=200, batch_size=100, activation_function='relu'
)

# Cross-validation for valence
val_mse_scores = []
val_r2_scores = []

for train_index, test_index in kf.split(train_x):
    X_train, X_test = train_x[train_index], train_x[test_index]
    y_train, y_test = train_y[train_index], train_y[test_index]

    clf.fit(X_train, y_train)
    predicted_val = clf.predict(X_test)

    val_mse_scores.append(metrics.mean_squared_error(y_test, predicted_val))
    val_r2_scores.append(metrics.r2_score(y_test, predicted_val))

print(f'Valence Mean Squared Error: {np.mean(val_mse_scores)}')
print(f'Valence r^2 Score: {np.mean(val_r2_scores)}')

# Define model for arousal
clfar = SupervisedDBNRegression(
    hidden_layers_structure=[100], learning_rate_rbm=0.05, learning_rate=0.05,
    n_epochs_rbm=10, n_iter_backprop=200, batch_size=100, activation_function='relu'
)

# Cross-validation for arousal
arousal_mse_scores = []
arousal_r2_scores = []

for train_index, test_index in kf.split(train_x):
    X_train1, X_test1 = train_x[train_index], train_x[test_index]
    y_train1, y_test1 = train_a[train_index], train_a[test_index]

    clfar.fit(X_train1, y_train1)
    arousal_val = clfar.predict(X_test1)

    arousal_mse_scores.append(metrics.mean_squared_error(y_test1, arousal_val))
    arousal_r2_scores.append(metrics.r2_score(y_test1, arousal_val))

print(f'Arousal Mean Squared Error: {np.mean(arousal_mse_scores)}')
print(f'Arousal r^2 Score: {np.mean(arousal_r2_scores)}')

# Predict emotion for first sample
first_arousal = arousal_val[0]
first_valence = predicted_val[0]

print(f'First Arousal Value: {first_arousal}')
print(f'First Valence Value: {first_valence}')

if first_arousal < 5 and first_valence > 0:
    print("Emotion: Relaxed")
elif first_arousal > 5 and first_valence > 0:
    print("Emotion: Happy")
elif first_arousal > 5 and first_valence < 0:
    print("Emotion: Angry")
else:
    print("Emotion: Bored")
